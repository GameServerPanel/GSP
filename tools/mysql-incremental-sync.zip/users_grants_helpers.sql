-- users_grants_helpers.sql
-- Helper queries that the shell script uses via `mysql -N -e`

-- List users with at least one non-usage grant (MySQL 5.7/8)
-- SELECT DISTINCT CONCAT(User,'@',Host) FROM mysql.user WHERE User <> '';

-- For a specific user/host, show grants:
-- SHOW GRANTS FOR 'user'@'host';

-- Mapping which dbs a grant touches is done in the shell (pattern parse `ON \`db\`.*`).
