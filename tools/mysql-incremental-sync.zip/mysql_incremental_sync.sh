#!/usr/bin/env bash
set -euo pipefail

# Loads options from ./mysql_sync.conf next to the script (if present)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONF_FILE="${SCRIPT_DIR}/mysql_sync.conf"
[[ -f "$CONF_FILE" ]] && source "$CONF_FILE"

# Defaults (in case not defined in conf)
: "${SRC_HOST:=source.example.com}"
: "${SRC_PORT:=3306}"
: "${SRC_USER:=binship}"
: "${SRC_PASS:=}"
: "${DST_HOST:=127.0.0.1}"
: "${DST_PORT:=3306}"
: "${DST_USER:=root}"
: "${DST_PASS:=}"
: "${INCLUDE_DBS:=}"
: "${EXCLUDE_DBS:=mysql,sys,performance_schema,information_schema}"
: "${SYNC_USERS_MODE:=grants_only}"  # off | grants_only | full_with_passwords
: "${RESTRICT_GRANTS_TO_SELECTED_DBS:=true}"
: "${WORKDIR:=/var/lib/mysql-bin-shipper}"
: "${USE_GTID:=false}"
: "${MYSQLDUMP_BIN:=mysqldump}"
: "${MYSQL_BIN:=mysql}"
: "${MYSQLBINLOG_BIN:=mysqlbinlog}"
: "${USE_SSH_TUNNEL:=false}"
: "${TUNNEL_HOST:=source.example.com}"
: "${TUNNEL_LOCAL_PORT:=3307}"
: "${DUMP_ADDITIONAL_ARGS:=--routines --triggers --events --hex-blob --single-transaction --skip-lock-tables}"

STATE_FILE="$WORKDIR/state.txt"
STATE_GTID="$WORKDIR/gtid.txt"
BASE_DUMP="$WORKDIR/base_dump.sql"
USERS_SQL="$WORKDIR/users_and_grants.sql"

mkdir -p "$WORKDIR"

# Build mysql client commands
src_host="$SRC_HOST"
src_port="$SRC_PORT"
if [[ "$USE_SSH_TUNNEL" == "true" ]]; then
  src_host="127.0.0.1"
  src_port="$TUNNEL_LOCAL_PORT"
fi

src_mysql=( "$MYSQL_BIN" -h "$src_host" -P "$src_port" -u "$SRC_USER" )
dst_mysql=( "$MYSQL_BIN" -h "$DST_HOST" -P "$DST_PORT" -u "$DST_USER" )
[[ -n "$SRC_PASS" ]] && src_mysql+=( "--password=$SRC_PASS" )
[[ -n "$DST_PASS" ]] && dst_mysql+=( "--password=$DST_PASS" )

# Helper: join list with spaces and backtick-escape db names
escape_db_list() {
  local list="$1"
  local out=()
  IFS=',' read -ra arr <<< "$list"
  for db in "${arr[@]}"; do
    db="${db// /}"
    [[ -z "$db" ]] && continue
    out+=( "`echo "$db" | sed "s/`/``/g"`" )
  done
  printf "%s " "${out[@]}"
}

# Build mysqldump database args
build_dump_db_args() {
  if [[ -n "$INCLUDE_DBS" ]]; then
    local incl_dbs; incl_dbs=$(escape_db_list "$INCLUDE_DBS")
    echo "--databases $incl_dbs"
  else
    echo "--all-databases"
  fi
}

# Determine databases list from source (filtered by include/exclude)
list_selected_databases() {
  local dblist
  dblist="$("${src_mysql[@]}" -N -e "SHOW DATABASES;")"
  local out=()
  while IFS= read -r db; do
    [[ -z "$db" ]] && continue
    if [[ -n "$INCLUDE_DBS" ]]; then
      # include only
      IFS=',' read -ra inc <<< "$INCLUDE_DBS"
      match=false
      for x in "${inc[@]}"; do
        [[ "$db" == "${x// /}" ]] && match=true && break
      done
      $match && out+=( "$db" )
    else
      # exclude some
      IFS=',' read -ra exc <<< "$EXCLUDE_DBS"
      skip=false
      for x in "${exc[@]}"; do
        [[ "$db" == "${x// /}" ]] && skip=true && break
      done
      $skip || out+=( "$db" )
    fi
  done <<< "$dblist"
  printf "%s\n" "${out[@]}"
}

check_log_bin() {
  echo ">> Checking log_bin on source..."
  local v; v=$("${src_mysql[@]}" -N -e "SHOW VARIABLES LIKE 'log_bin';" | awk '{print $2}')
  if [[ "$v" != "ON" && "$v" != "ON\r" ]]; then
    echo "ERROR: log_bin is not ON on source." >&2
    exit 1
  fi
}

get_versions() {
  SRC_VER=$("${src_mysql[@]}" -N -e "SELECT VERSION();" || true)
  DST_VER=$("${dst_mysql[@]}" -N -e "SELECT VERSION();" || true)
  echo "   Source: $SRC_VER"
  echo "   Dest  : $DST_VER"
}

dump_and_apply_users_grants() {
  [[ "$SYNC_USERS_MODE" == "off" ]] && { echo ">> User/Grant sync: off"; return 0; }

  echo ">> Building users & grants SQL from source..."
  : > "$USERS_SQL"

  # Get candidate users
  mapfile -t users < <("${src_mysql[@]}" -N -e "SELECT CONCAT(User,'@',Host) FROM mysql.user WHERE User<>'';")

  # Gather selected DBs for filtering grants
  mapfile -t selected_dbs < <(list_selected_databases)

  for uh in "${users[@]}"; do
    u="${uh%@*}"; h="${uh#*@}"

    # Collect grants for the user
    mapfile -t grants < <("${src_mysql[@]}" -N -e "SHOW GRANTS FOR '${u}'@'${h}';" || true)
    [[ "${#grants[@]}" -eq 0 ]] && continue

    # Determine if user touches selected DBs (or skip if no intersect when restricting)
    use_user=true
    if [[ "$RESTRICT_GRANTS_TO_SELECTED_DBS" == "true" && "${#selected_dbs[@]}" -gt 0 ]]; then
      use_user=false
      for g in "${grants[@]}"; do
        for db in "${selected_dbs[@]}"; do
          # match ON `db`.* or ON db.*
          if [[ "$g" =~ \ ON\ \`?$db\`?\.\*\  ]]; then
            use_user=true; break 2
          fi
        done
      done
    fi
    $use_user || continue

    # Create user line(s)
    if [[ "$SYNC_USERS_MODE" == "full_with_passwords" ]]; then
      # Pull plugin + hash (MySQL 8 uses 'authentication_string')
      read -r plugin authstr <<< $("${src_mysql[@]}" -N -e "SELECT plugin, authentication_string FROM mysql.user WHERE user='${u}' AND host='${h}' LIMIT 1;")
      if [[ -n "$plugin" && -n "$authstr" ]]; then
        echo "CREATE USER IF NOT EXISTS \`${u}\`@\`${h}\` IDENTIFIED WITH \`${plugin}\` AS '${authstr}';" >> "$USERS_SQL"
      else
        # Fallback: create without password (admin should rotate)
        echo "CREATE USER IF NOT EXISTS \`${u}\`@\`${h}\`;" >> "$USERS_SQL"
      fi
    else
      # grants_only: ensure user exists (no password)
      echo "CREATE USER IF NOT EXISTS \`${u}\`@\`${h}\`;" >> "$USERS_SQL"
    fi

    # Apply grants (optionally filtered to selected DBs)
    for g in "${grants[@]}"; do
      if [[ "$RESTRICT_GRANTS_TO_SELECTED_DBS" == "true" && "${#selected_dbs[@]}" -gt 0 ]]; then
        grant_ok=false
        for db in "${selected_dbs[@]}"; do
          if [[ "$g" =~ \ ON\ \`?$db\`?\.\*\  ]]; then
            grant_ok=true; break
          fi
        done
        $grant_ok || continue
      fi
      # Normalize to end with semicolon
      [[ "$g" =~ \;$ ]] || g="$g;"
      echo "$g" >> "$USERS_SQL"
    done
  done

  echo ">> Applying users & grants to destination..."
  "${dst_mysql[@]}" < "$USERS_SQL"
}

do_initial_dump() {
  echo ">> Initializing base dump..."
  local db_args; db_args=$(build_dump_db_args)

  "$MYSQLDUMP_BIN" \
    -h "$src_host" -P "$src_port" -u "$SRC_USER" ${SRC_PASS:+--password="$SRC_PASS"} \
    $db_args --master-data=2 $DUMP_ADDITIONAL_ARGS > "$BASE_DUMP"

  echo ">> Loading dump into destination..."
  "${dst_mysql[@]}" < "$BASE_DUMP"

  echo ">> Extracting starting position/GTID..."
  if [[ "$USE_GTID" == "true" ]]; then
    # Capture GTID sets from source
    GTID_EXEC=$("${src_mysql[@]}" -N -e "SELECT @@GLOBAL.gtid_executed;")
    echo "$GTID_EXEC" > "$STATE_GTID"
    echo ">> Saved GTID state: $(cat "$STATE_GTID")"
  else
    local line file pos
    line="$(grep -m1 -E '^-- CHANGE MASTER TO MASTER_LOG_FILE=' "$BASE_DUMP" || true)"
    file="$(echo "$line" | sed -n "s/.*MASTER_LOG_FILE='\([^']\+\)'.*/\1/p")"
    pos="$(echo "$line" | sed -n "s/.*MASTER_LOG_POS=\([0-9]\+\).*/\1/p")"
    if [[ -z "$file" || -z "$pos" ]]; then
      echo "ERROR: Could not parse binlog file/pos from dump." >&2
      exit 1
    fi
    echo "$file $pos" > "$STATE_FILE"
    echo ">> Initial state saved: $(cat "$STATE_FILE")"
  fi

  dump_and_apply_users_grants
}

apply_incremental() {
  if [[ ! -f "$STATE_FILE" && ! -f "$STATE_GTID" ]]; then
    echo ">> No state found. Run with --init first (or pass --init now)."
    exit 1
  fi

  echo ">> Determining current source tip..."
  local cur_file cur_pos
  if [[ "$USE_GTID" == "true" ]]; then
    :
  else
    read -r cur_file cur_pos < <("${src_mysql[@]}" -N -e "SHOW MASTER STATUS" | awk '{print $1, $2}')
    if [[ -z "$cur_file" || -z "$cur_pos" ]]; then
      echo "ERROR: SHOW MASTER STATUS returned empty. Are binlogs enabled?" >&2
      exit 1
    fi
    echo ">> Source tip: $cur_file $cur_pos"
  fi

  echo ">> Streaming and applying changes..."
  if [[ "$USE_GTID" == "true" ]]; then
    local gtid_start; gtid_start="$(cat "$STATE_GTID")"
    # Use mysqlbinlog with --exclude-gtids to avoid replaying applied transactions
    "$MYSQLBINLOG_BIN" \
      --read-from-remote-server \
      --host="$src_host" --port="$src_port" --user="$SRC_USER" ${SRC_PASS:+--password="$SRC_PASS"} \
      --base64-output=DECODE-ROWS --verbose \
      --exclude-gtids="$gtid_start" \
      --to-last-log \
    | "${dst_mysql[@]}"

    # Update GTID state to current source executed set
    GTID_EXEC=$("${src_mysql[@]}" -N -e "SELECT @@GLOBAL.gtid_executed;")
    echo "$GTID_EXEC" > "$STATE_GTID"
    echo ">> Updated GTID state."
  else
    if [[ ! -f "$STATE_FILE" ]]; then
      echo "ERROR: Missing $STATE_FILE; run --init first." >&2
      exit 1
    fi
    local start_file start_pos
    read -r start_file start_pos < "$STATE_FILE"
    if [[ -z "$start_file" || -z "$start_pos" ]]; then
      echo "ERROR: Corrupt $STATE_FILE" >&2
      exit 1
    fi

    "$MYSQLBINLOG_BIN" \
      --read-from-remote-server \
      --host="$src_host" --port="$src_port" --user="$SRC_USER" ${SRC_PASS:+--password="$SRC_PASS"} \
      --start-position="$start_pos" \
      --base64-output=DECODE-ROWS --verbose \
      --to-last-log "$start_file" \
    | "${dst_mysql[@]}"

    # Bump state to current tip
    echo "$cur_file $cur_pos" > "$STATE_FILE"
    echo ">> Updated state to: $(cat "$STATE_FILE")"
  fi

  # Users & grants can be reapplied safely (GRANTs are idempotent)
  dump_and_apply_users_grants
}

usage() {
  cat <<EOF
Usage: $0 [--init] [--once]

  --init   Take a base dump, load it, save state (file/pos or GTID), sync users/grants.
  (no arg) Apply incremental changes since last run; re-sync users/grants.
EOF
}

main() {
  check_log_bin
  echo ">> Version check (warn only)"
  get_versions

  case "${1:-}" in
    --help|-h) usage; exit 0 ;;
    --init) do_initial_dump ;;
    "" ) apply_incremental ;;
    *) usage; exit 1 ;;
  esac
  echo ">> Done."
}

main "$@"
