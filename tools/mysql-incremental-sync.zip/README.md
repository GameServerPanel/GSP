# MySQL Incremental Sync (Poor-Man’s Replication) — Multi‑DB + Users/Grants

This package gives you a production‑friendly way to **pull** data from a *source* MySQL/MariaDB server and **apply only the changes since last run** to a *destination* server. It also includes options to **synchronize database users and permissions** relevant to the databases you care about.

> Works when you can’t or don’t want to set up full native replication; great for periodic DR syncs, lab refreshes, and pull-based staging updates.

---

## What you get

- **Incremental data sync** using the source’s binary logs (binlogs).
- **Multi‑database selection** (include/exclude lists).
- **User & GRANT sync**: recreate users (optionally with password hashes) and apply their GRANTs for the selected databases.
- **Single config file** you can copy between environments.
- **Stateful** file/position (or GTID) tracking so subsequent runs only apply changes.
- **No password leaks to process list** if you use `~/.my.cnf` or env files.

---

## Files

- `mysql_incremental_sync.sh` – main script
- `mysql_sync.conf.example` – copy to `mysql_sync.conf` and edit
- `users_grants_helpers.sql` – helper SQL used for user/grant extraction
- `README.md` – this document

---

## Quick start

1) **Enable binlogs on the SOURCE** (in `my.cnf`/`mysqld.cnf`):
```ini
[mysqld]
log_bin=ON
server_id=101         # must be unique in your fleet
binlog_format=ROW     # recommended
```
Restart the source MySQL if needed.

2) **Create a user on the SOURCE** with minimally required privileges (adjust host):
```sql
CREATE USER 'binship'@'%' IDENTIFIED BY 'strong_password';
GRANT REPLICATION CLIENT, RELOAD, SELECT, SHOW VIEW ON *.* TO 'binship'@'%';
-- For remote binlog pull:
GRANT REPLICATION SLAVE ON *.* TO 'binship'@'%';
FLUSH PRIVILEGES;
```

3) **Copy the config**:
```bash
cp mysql_sync.conf.example mysql_sync.conf
nano mysql_sync.conf   # edit values
```

4) **First run** (from the DESTINATION box):
```bash
chmod +x mysql_incremental_sync.sh
./mysql_incremental_sync.sh --init
```
That will take a consistent base dump (limited to your `INCLUDE_DBS` if set), load it into the destination, store the initial binlog file/pos, and (optionally) sync users & grants.

5) **Incremental runs**:
```bash
./mysql_incremental_sync.sh
```
Add to cron/systemd to run every N minutes.

---

## Configuration

Edit `mysql_sync.conf` (kept separate from the script).

```bash
##############################
# SOURCE (pull from)
##############################
SRC_HOST="source.example.com"
SRC_PORT="3306"
SRC_USER="binship"
SRC_PASS="change_me"      # leave empty to use ~/.my.cnf

##############################
# DESTINATION (apply to)
##############################
DST_HOST="127.0.0.1"
DST_PORT="3306"
DST_USER="root"
DST_PASS="change_me"      # leave empty to use ~/.my.cnf

##############################
# WHAT TO SYNC (databases)
##############################
# Include/Exclude are comma-separated lists. Use one or the other.
INCLUDE_DBS="main_db,app_db,analytics"    # sync only these
EXCLUDE_DBS="mysql,sys,performance_schema,information_schema"  # ignored if INCLUDE_DBS is set

##############################
# USERS / GRANTS SYNC
##############################
# Sync users/grants that have privileges on the selected DBs.
# Mode: off | grants_only | full_with_passwords
SYNC_USERS_MODE="grants_only"

# When true, GRANTs are filtered to only the selected DBs.
RESTRICT_GRANTS_TO_SELECTED_DBS="true"

# Password handling for 'full_with_passwords':
#   - For MySQL 8: uses CREATE USER ... IDENTIFIED WITH <plugin> AS '<hash>'
#   - For MySQL 5.7: uses IDENTIFIED BY PASSWORD '<hash>' where possible
#
# If you have mixed versions, prefer grants_only (create users with random pwd and
# let your app rotate), or standardize auth plugins first.
##############################

##############################
# BEHAVIOR
##############################
# Working dir for state (binlog file/pos).
WORKDIR="/var/lib/mysql-bin-shipper"
# Use GTID tracking instead of file/pos (if enabled on source). Values: true|false
USE_GTID="false"
# Path to mysqldump/mysql/mysqlbinlog binaries (override if not in PATH)
MYSQLDUMP_BIN="mysqldump"
MYSQL_BIN="mysql"
MYSQLBINLOG_BIN="mysqlbinlog"

# SSH tunneling (optional). If true, the script expects an existing local tunnel.
USE_SSH_TUNNEL="false"
TUNNEL_HOST="source.example.com"
TUNNEL_LOCAL_PORT="3307"

# Dump tuning
DUMP_ADDITIONAL_ARGS="--routines --triggers --events --hex-blob --single-transaction --skip-lock-tables"
```

### Examples
- **Only specific DBs**: set `INCLUDE_DBS="main_db,app_db"` and leave `EXCLUDE_DBS` blank.
- **Everything except system DBs**: leave `INCLUDE_DBS` blank, keep `EXCLUDE_DBS` default.
- **Users/grants only, no passwords**: `SYNC_USERS_MODE="grants_only"`
- **Full recreate users with hashed passwords**: `SYNC_USERS_MODE="full_with_passwords"`

---

## Scheduling

**Cron (every 10 minutes):**
```cron
*/10 * * * * /path/to/mysql_incremental_sync.sh >> /var/log/mysql-incr-sync.log 2>&1
```

**systemd unit (optional):**
```ini
[Unit]
Description=MySQL Incremental Sync
After=network-online.target

[Service]
Type=simple
WorkingDirectory=/path/to/dir
ExecStart=/path/to/mysql_incremental_sync.sh
Restart=on-failure

[Install]
WantedBy=multi-user.target
```

---

## Notes & caveats

- **DDL drift**: Apply schema changes on source; the script replays binlogs assuming source-of-truth.
- **GTID**: If both servers use GTIDs, set `USE_GTID=true` for cleaner state.
- **Version mismatches**: You can replicate from newer to older only within compatible ranges; prefer equal majors.
- **Security**: Prefer `~/.my.cnf` or `mysql_config_editor` to avoid passwords in env/ps.
- **Networking**: Consider SSH tunnels if you can’t open port 3306 from dest → source.

---

## Uninstall / Reset

Delete the working directory to force a re‑init:
```bash
rm -rf /var/lib/mysql-bin-shipper
```
Then run with `--init` again.
