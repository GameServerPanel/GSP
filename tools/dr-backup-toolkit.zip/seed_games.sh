#!/usr/bin/env bash
set -euo pipefail

# seed_games.sh
# Edit APP_IDS to include dedicated server app IDs you want to pre-seed in BASE_GAMES.
# Example includes a few common servers (comment/uncomment as needed).

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONF="${SCRIPT_DIR}/dr_backup.conf"
[[ -f "$CONF" ]] && source "$CONF"

STEAMCMD="${STEAMCMD_BIN:-steamcmd}"
BASE="${BASE_GAMES:-/srv/dr-backup/base_games}"
USER="${STEAM_LOGIN_USER:-anonymous}"
PASS="${STEAM_LOGIN_PASS:-}"

# Common dedicated server app IDs (examples, verify for your titles):
APP_IDS=(
  # 233780  # Arma 3 Dedicated Server
  # 232330  # Counter-Strike Dedicated Server (old HLDS)
  # 258550  # Rust Dedicated Server
  # 896660  # Valheim Dedicated Server
  # 4020    # GMod (example, non-dedi)
)

mkdir -p "$BASE"
LOGIN="+login ${USER} ${PASS}"
[[ "$USER" == "anonymous" ]] && LOGIN="+login anonymous"

for app in "${APP_IDS[@]}"; do
  install_dir="${BASE}/${app}"
  mkdir -p "$install_dir"
  echo ">> Seeding app ${app} to ${install_dir}"
  "$STEAMCMD" +force_install_dir "${install_dir}" ${LOGIN} +app_update "${app}" validate +quit
done

echo ">> Base seeding complete."
