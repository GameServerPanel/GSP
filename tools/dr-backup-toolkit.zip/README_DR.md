# DR Backup for Remote Game Servers (Bandwidth-Efficient)

This toolkit lets you back up **multiple remote game servers** to a **DR backup server** while minimizing bandwidth:

1. **Workshop mirroring:** Detect which **Steam Workshop items** are in use on each remote host and ensure they are present on the DR server (via SteamCMD), so later file diffs are tiny.
2. **Base copies of games on DR:** Optionally keep **base dedicated server installs** on the DR server (via SteamCMD), so initial syncs need minimal transfer.
3. **Incremental snapshots:** Use `rsync --link-dest` to create time-stamped snapshots that only store **changed files** (unchanged files are hard links).

Everything is **pull-based** from the DR server (no agents required), using SSH and rsync.

---

## Contents

- `backup_pull.sh` — main orchestrator to probe remotes, mirror Workshop, and pull game server folders as incremental snapshots.
- `steam_workshop_sync.sh` — SteamCMD wrapper to fetch Workshop items (anonymous by default or login if provided).
- `seed_games.sh` — optional: pre-seed base game installs on the DR server using SteamCMD (dedicated server app IDs).
- `remote_probe.sh` — helper script executed on the **remote** via SSH to enumerate Workshop items and validate game directories.
- `dr_backup.conf.example` — copy to `dr_backup.conf` and edit.
- `servers.csv.example` — define your remote hosts and directories.
- `README_DR.md` — this document.

---

## Quick Start

1) **Install dependencies on the DR server** (Debian/Ubuntu):
```bash
sudo apt-get update
sudo apt-get install -y rsync git jq
# SteamCMD (Linux):
sudo mkdir -p /opt/steamcmd && cd /opt/steamcmd
sudo apt-get install -y lib32gcc-s1 curl
curl -sSL https://steamcdn-a.akamaihd.net/client/installer/steamcmd_linux.tar.gz | sudo tar -xz
sudo ln -sf /opt/steamcmd/steamcmd.sh /usr/local/bin/steamcmd
```

2) **Copy config & servers list:**
```bash
cp dr_backup.conf.example dr_backup.conf
cp servers.csv.example servers.csv
chmod 600 dr_backup.conf    # contains creds if you add them
```

3) **Edit `dr_backup.conf`:**
- Set `BACKUP_ROOT`, `WORKSHOP_CACHE`, `BASE_GAMES` (directories on the DR server).
- Confirm `STEAMCMD_BIN` path.
- Optional: set `STEAM_LOGIN_USER` and `STEAM_LOGIN_PASS` for items that require login (anonymous works for many Workshop items).

4) **Describe your remote servers in `servers.csv`:**
Each line:  
`name,ssh,game_dirs,workshop_dirs`

- `name`: a short handle for the remote (e.g., `kc-01`).
- `ssh`: SSH target (e.g., `gameserver@kc-01.example.com`).
- `game_dirs`: colon-separated list of **server instance roots** to back up (e.g., `/home/gameserver/arma3:/home/gameserver/cs16`).
- `workshop_dirs`: colon-separated paths to scan for Workshop (e.g., `/home/gameserver/steam/steamapps/workshop/content`).
  - You can point to **parent** of the per-app folders; the probe will recurse.

Example row:
```
kc-01,gameserver@173.208.xx.xx,/home/gameserver/arma3/server:/home/gameserver/valheim/server,/home/gameserver/steam/steamapps/workshop/content
```

5) **(Optional) Seed base game installs on DR:**
Edit `seed_games.sh` to include your app IDs, then run:
```bash
./seed_games.sh
```

6) **Run the backup pull:**
```bash
chmod +x *.sh
./backup_pull.sh --config ./dr_backup.conf --servers ./servers.csv
```
- The script will:
  1. Probe each remote for Workshop items.
  2. Mirror missing Workshop items to `WORKSHOP_CACHE`.
  3. Pull each server folder into a timestamped snapshot under `BACKUP_ROOT/servers/<name>/<timestamp>/` using `rsync --link-dest` to the **previous snapshot** (if any) or to `BASE_GAMES` on the first run.

7) **Schedule (cron):**
```cron
# Every hour
0 * * * * /opt/dr-backup/backup_pull.sh --config /opt/dr-backup/dr_backup.conf --servers /opt/dr-backup/servers.csv --quiet >> /var/log/dr-backup.log 2>&1
```

---

## Layout on DR server

```
BACKUP_ROOT/
  servers/
    <name>/
      current -> <timestamp>/
      20250906-070500/      # snapshot (rsync mirror)
      20250905-230100/
  workshop_cache/
    <appid>/<itemid>/...
  base_games/               # optional pre-seeded dedicated server installs
```

Each snapshot is a **full tree** but unchanged files are hard links (space-efficient).

---

## Notes & Tips

- First-run bandwidth drops dramatically if your `BASE_GAMES` tree matches your remote server layout. If not, the script still works; subsequent runs will be very efficient thanks to `--link-dest` to the **previous snapshot**.
- Workshop download often works **anonymous**, but some items require login — set `STEAM_LOGIN_USER`/`PASS`.
- Ensure SSH from DR → remote works without prompts (SSH keys).
- For very large trees, consider `--partial --inplace` rsync flags (not enabled by default).
- To restore, pick a snapshot and `rsync`/copy it back to a target server.
