#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONF="${SCRIPT_DIR}/dr_backup.conf"
SERVERS="${SCRIPT_DIR}/servers.csv"
QUIET="${QUIET_DEFAULT:-false}"

log() { [[ "$QUIET" == "true" ]] || echo -e "$@"; }
die() { echo "ERROR: $*" >&2; exit 1; }

# CLI
while [[ $# -gt 0 ]]; do
  case "$1" in
    --config) CONF="$2"; shift 2;;
    --servers) SERVERS="$2"; shift 2;;
    --quiet) QUIET="true"; shift;;
    -h|--help)
      cat <<EOF
Usage: $0 [--config dr_backup.conf] [--servers servers.csv] [--quiet]
EOF
      exit 0;;
    *) die "Unknown arg $1";;
  esac
done

[[ -f "$CONF" ]] || die "Config not found: $CONF"
source "$CONF"
[[ -f "$SERVERS" ]] || die "Servers list not found: $SERVERS"

mkdir -p "${BACKUP_ROOT}/servers" "${WORKSHOP_CACHE}" "${BASE_GAMES}"

timestamp="$(date +%Y%m%d-%H%M%S)"

# Read servers.csv (skip comments/blank)
while IFS=, read -r name ssh game_dirs workshop_dirs; do
  [[ -z "${name// /}" ]] && continue
  [[ "$name" =~ ^# ]] && continue

  log "==== ${name} (${ssh}) ===="

  # Probe for workshop items on remote
  probe_cmd="$(sed 's/"/\\"/g' "${SCRIPT_DIR}/remote_probe.sh")"  # inline the script over SSH
  json="$(ssh ${SSH_OPTS} "$ssh" "bash -s -- \"${workshop_dirs}\"" <<< "$probe_cmd" || true)"
  if [[ -n "$json" ]]; then
    # Parse workshop entries using jq if available, else awk fallback
    if command -v jq >/dev/null 2>&1; then
      count=$(echo "$json" | jq '.workshop | length')
      log ">> Found ${count} workshop items."
      for ((i=0; i<count; i++)); do
        appid=$(echo "$json" | jq -r ".workshop[$i].appid")
        itemid=$(echo "$json" | jq -r ".workshop[$i].itemid")
        "${SCRIPT_DIR}/steam_workshop_sync.sh" \
          --cache "${WORKSHOP_CACHE}" \
          --appid "${appid}" --itemid "${itemid}" \
          --steamcmd "${STEAMCMD_BIN}" \
          --user "${STEAM_LOGIN_USER}" --pass "${STEAM_LOGIN_PASS}"
      done
    else
      # rudimentary parse
      echo "$json" | tr '{}' '\n' | grep '"appid"' | while read -r line; do
        appid=$(echo "$line" | sed -n 's/.*"appid":"\([0-9]\+\)".*/\1/p')
        itemid=$(echo "$line" | sed -n 's/.*"itemid":"\([0-9]\+\)".*/\1/p')
        [[ -n "$appid" && -n "$itemid" ]] || continue
        "${SCRIPT_DIR}/steam_workshop_sync.sh" \
          --cache "${WORKSHOP_CACHE}" \
          --appid "${appid}" --itemid "${itemid}" \
          --steamcmd "${STEAMCMD_BIN}" \
          --user "${STEAM_LOGIN_USER}" --pass "${STEAM_LOGIN_PASS}"
      done
    fi
  else
    log ">> No workshop data returned (or probe failed)."
  fi

  # Backup game directories
  IFS=':' read -r -a dirs <<< "$game_dirs"
  for d in "${dirs[@]}"; do
    [[ -z "$d" ]] && continue
    # Destination snapshot dir & link-dest
    server_root="${BACKUP_ROOT}/servers/${name}"
    snap="${server_root}/${timestamp}"
    last_link="${server_root}/current"
    mkdir -p "$snap"

    if [[ -L "$last_link" && -d "$last_link" ]]; then
      linkdest="$(readlink -f "$last_link")"
    else
      linkdest="${BASE_GAMES}"
    fi

    log ">> Rsync ${ssh}:${d} -> ${snap} (link-dest: ${linkdest})"
    rsync ${RSYNC_OPTS} --link-dest="${linkdest}" -e "ssh ${SSH_OPTS}" "${ssh}:${d}/" "${snap}/$(basename "$d")/"

    # Update current symlink
    ln -sfn "$snap" "$last_link"
  done

done < "$SERVERS"

log "== DONE =="
