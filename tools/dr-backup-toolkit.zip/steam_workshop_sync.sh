#!/usr/bin/env bash
set -euo pipefail

# steam_workshop_sync.sh --cache <dir> --appid <id> --itemid <id> [--steamcmd /path/to/steamcmd] [--user u --pass p]
CACHE=""
APPID=""
ITEMID=""
STEAMCMD="${STEAMCMD_BIN:-steamcmd}"
USER="${STEAM_LOGIN_USER:-anonymous}"
PASS="${STEAM_LOGIN_PASS:-}"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --cache) CACHE="$2"; shift 2;;
    --appid) APPID="$2"; shift 2;;
    --itemid) ITEMID="$2"; shift 2;;
    --steamcmd) STEAMCMD="$2"; shift 2;;
    --user) USER="$2"; shift 2;;
    --pass) PASS="$2"; shift 2;;
    *) echo "Unknown arg $1" >&2; exit 1;;
  esac
done

[[ -n "$CACHE" && -n "$APPID" && -n "$ITEMID" ]] || { echo "Missing args"; exit 1; }

TARGET="${CACHE}/${APPID}/${ITEMID}"
if [[ -d "$TARGET" ]]; then
  echo "Workshop ${APPID}/${ITEMID} already present."
  exit 0
fi

mkdir -p "${CACHE}/${APPID}"

LOGIN="+login ${USER} ${PASS}"
if [[ "$USER" == "anonymous" ]]; then LOGIN="+login anonymous"; fi

# Download
"$STEAMCMD" +force_install_dir "${CACHE}" ${LOGIN} +workshop_download_item "${APPID}" "${ITEMID}" validate +quit

# After download, SteamCMD places files under ${CACHE}/steamapps/workshop/content/<appid>/<itemid>
SRC="${CACHE}/steamapps/workshop/content/${APPID}/${ITEMID}"
if [[ -d "$SRC" ]]; then
  mkdir -p "${CACHE}/${APPID}"
  # Move/rsync to canonical cache path
  rsync -a "${SRC}/" "${TARGET}/"
  echo "Fetched ${APPID}/${ITEMID} to ${TARGET}"
else
  echo "WARN: Workshop item not found at ${SRC}" >&2
fi
