#!/usr/bin/env bash
set -euo pipefail

# Usage (runs on remote): remote_probe.sh <workshop_dirs_colon_sep>
# Outputs JSON to stdout with fields:
#  {
#    "workshop": [ {"appid":"<id>", "itemid":"<id>", "path":"/abs/path"}, ... ]
#  }
workshop_dirs="${1:-}"
echo '{ "workshop": ['
first=true

IFS=':' read -r -a dirs <<< "${workshop_dirs}"
for root in "${dirs[@]}"; do
  [[ -d "$root" ]] || continue
  # Expect /root/<appid>/<itemid>
  while IFS= read -r -d '' itemdir; do
    # itemdir looks like .../content/<appid>/<itemid>
    base="$(basename "$itemdir")"
    appdir="$(dirname "$itemdir")"
    appid="$(basename "$appdir")"
    itemid="$base"
    # Validate numeric
    if [[ "$appid" =~ ^[0-9]+$ && "$itemid" =~ ^[0-9]+$ ]]; then
      if $first; then first=false; else echo ','; fi
      printf '  {"appid":"%s","itemid":"%s","path":"%s"}' "$appid" "$itemid" "$itemdir"
    fi
  done < <(find "$root" -type d -mindepth 2 -maxdepth 2 -print0 2>/dev/null)
done

echo '] }'
